            <footer class="text-center bg-primary text-white w-100" style="box-shadow: 0 0 1em #000; border-radius:10px;">
                <p class="pb-2 pt-2">
                    Génesis Lloret Ramos - <?php echo date("Y"); ?>
                </p>
            </footer>
        </div>
    </body>
</html>